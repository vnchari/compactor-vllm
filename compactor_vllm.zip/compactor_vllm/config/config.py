import os
from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional

from transformers import AutoConfig


class AttentionBackend(Enum):
    FLASH_ATTENTION = auto()
    COMPACTOR_TRITON = auto()


@dataclass
class EngineConfig:
    model: str
    path: Optional[str] = None
    max_num_batches: int = 512
    max_model_len: int = 40960
    gpu_memory_utilization: float = 0.9
    tensor_parallel_size: int = 1
    enforce_eager: bool = False
    hf_config: AutoConfig | None = None
    eos: int = -1
    kvcache_page_size: int = 128
    leverage_sketch_size: int = 64
    attention_backend: AttentionBackend = AttentionBackend.COMPACTOR_TRITON

    def __post_init__(self):
        if self.path is not None:
            assert os.path.isdir(self.path)
        assert 1 <= self.tensor_parallel_size <= 8
        self.hf_config = AutoConfig.from_pretrained(self.model)
        self.max_model_len = min(
            self.max_model_len, self.hf_config.max_position_embeddings
        )
