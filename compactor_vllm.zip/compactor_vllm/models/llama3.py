import os
from glob import glob

import torch
import torch.distributed as dist
import tqdm
from safetensors import safe_open
from torch import nn
from transformers import LlamaConfig

from compactor_vllm.compression import COMPRESSION_REGISTRY
from compactor_vllm.layers.activation import SiluAndMul
from compactor_vllm.layers.attention import Attention
from compactor_vllm.layers.embed_head import ParallelLMHead, VocabParallelEmbedding
from compactor_vllm.layers.layernorm import RMSNorm
from compactor_vllm.layers.linear import (
    MergedColumnParallelLinear,
    QKVParallelLinear,
    RowParallelLinear,
)
from compactor_vllm.layers.rotary_embedding import get_rope
from compactor_vllm.utils.context import get_context


class LlamaAttention(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: int,
        max_position: int = 4096 * 32,
        head_dim: int | None = None,
        qkv_bias: bool = False,
        rope_theta: float = 10000,
        rope_scaling: dict | None = None,
    ) -> None:
        super().__init__()
        tp_size = dist.get_world_size()
        self.total_num_heads = num_heads
        assert self.total_num_heads % tp_size == 0
        self.num_heads = self.total_num_heads // tp_size
        self.total_num_kv_heads = num_kv_heads
        assert self.total_num_kv_heads % tp_size == 0
        self.num_kv_heads = self.total_num_kv_heads // tp_size
        self.head_dim = head_dim or hidden_size // self.total_num_heads
        self.q_size = self.num_heads * self.head_dim
        self.kv_size = self.num_kv_heads * self.head_dim
        self.scaling = self.head_dim**-0.5

        self.qkv_proj = QKVParallelLinear(
            hidden_size,
            self.head_dim,
            self.total_num_heads,
            self.total_num_kv_heads,
            bias=qkv_bias,
        )
        self.o_proj = RowParallelLinear(
            self.total_num_heads * self.head_dim,
            hidden_size,
            bias=False,
        )
        if rope_scaling is not None:
            rope_scaling_tuple = (
                rope_scaling["rope_type"],
                rope_scaling["factor"],
                rope_scaling["low_freq_factor"],
                rope_scaling["high_freq_factor"],
                rope_scaling["original_max_position_embeddings"],
            )
        else:
            rope_scaling_tuple = None

        self.rotary_emb = get_rope(
            self.head_dim,
            rotary_dim=self.head_dim,
            max_position=max_position,
            base=rope_theta,
            rope_scaling=rope_scaling_tuple,
        )
        self.attn = Attention(
            self.num_heads,
            self.head_dim,
            self.scaling,
            self.num_kv_heads,
        )

    def forward(
        self,
        positions: torch.Tensor,
        hidden_states: torch.Tensor,
    ) -> torch.Tensor:
        context = get_context()
        qkv = self.qkv_proj(hidden_states)
        q, k, v = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)
        q = q.view(-1, self.num_heads, self.head_dim)
        k = k.view(-1, self.num_kv_heads, self.head_dim)
        v = v.view(-1, self.num_kv_heads, self.head_dim)
        scores = None
        if context.is_prefill and context.do_compression:
            scores = COMPRESSION_REGISTRY[context.compression_method].pre_rope_scoring(
                q, k, v, context=context
            )

        q, k = self.rotary_emb(positions, q, k)

        if context.is_prefill and context.do_compression:
            scores = COMPRESSION_REGISTRY[context.compression_method].post_rope_scoring(
                q, k, v, scores, context
            )

        o = self.attn(q, k, v, scores)
        output = self.o_proj(o.flatten(1, -1))
        return output


class LlamaMLP(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int,
        hidden_act: str,
        mlp_bias: bool,
    ) -> None:
        super().__init__()
        self.gate_up_proj = MergedColumnParallelLinear(
            hidden_size,
            [intermediate_size] * 2,
            bias=mlp_bias,
        )
        self.down_proj = RowParallelLinear(
            intermediate_size,
            hidden_size,
            bias=mlp_bias,
        )
        assert hidden_act == "silu"
        self.act_fn = SiluAndMul()

    def forward(self, x):
        gate_up = self.gate_up_proj(x)
        x = self.act_fn(gate_up)
        x = self.down_proj(x)
        return x


class LlamaDecoderLayer(nn.Module):
    def __init__(
        self,
        config: LlamaConfig,
    ) -> None:
        super().__init__()
        self.self_attn = LlamaAttention(
            hidden_size=config.hidden_size,
            num_heads=config.num_attention_heads,
            num_kv_heads=config.num_key_value_heads,
            max_position=config.max_position_embeddings,
            qkv_bias=getattr(config, "attention_bias", False),
            head_dim=getattr(config, "head_dim", None),
            rope_theta=getattr(config, "rope_theta", 500000.0),
            rope_scaling=getattr(config, "rope_scaling", None),
        )
        self.mlp = LlamaMLP(
            hidden_size=config.hidden_size,
            intermediate_size=config.intermediate_size,
            hidden_act=config.hidden_act,
            mlp_bias=config.mlp_bias,
        )
        self.input_layernorm = RMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.post_attention_layernorm = RMSNorm(
            config.hidden_size, eps=config.rms_norm_eps
        )

    def forward(
        self,
        positions: torch.Tensor,
        hidden_states: torch.Tensor,
        residual: torch.Tensor | None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if residual is None:
            hidden_states, residual = self.input_layernorm(hidden_states), hidden_states
        else:
            hidden_states, residual = self.input_layernorm(hidden_states, residual)
        hidden_states = self.self_attn(positions, hidden_states)
        hidden_states, residual = self.post_attention_layernorm(hidden_states, residual)
        hidden_states = self.mlp(hidden_states)
        return hidden_states, residual


class LlamaModel(nn.Module):
    def __init__(
        self,
        config: LlamaConfig,
    ) -> None:
        super().__init__()
        self.embed_tokens = VocabParallelEmbedding(
            config.vocab_size, config.hidden_size
        )
        self.layers = nn.ModuleList(
            [LlamaDecoderLayer(config) for _ in range(config.num_hidden_layers)]
        )
        self.norm = RMSNorm(config.hidden_size, eps=config.rms_norm_eps)

    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
    ) -> torch.Tensor:
        hidden_states = self.embed_tokens(input_ids)
        residual = None
        for layer in self.layers:
            hidden_states, residual = layer(positions, hidden_states, residual)
        hidden_states, _ = self.norm(hidden_states, residual)
        return hidden_states


class LlamaForCausalLM(nn.Module):
    packed_modules_mapping = {
        "q_proj": ("qkv_proj", "q"),
        "k_proj": ("qkv_proj", "k"),
        "v_proj": ("qkv_proj", "v"),
        "gate_proj": ("gate_up_proj", 0),
        "up_proj": ("gate_up_proj", 1),
    }

    def __init__(self, config: LlamaConfig) -> None:
        super().__init__()
        self.model = LlamaModel(config)
        self.lm_head = ParallelLMHead(config.vocab_size, config.hidden_size)
        if config.tie_word_embeddings:
            self.lm_head.weight.data = self.model.embed_tokens.weight.data

    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
    ) -> torch.Tensor:
        return self.model(input_ids, positions)

    def compute_logits(
        self,
        hidden_states: torch.Tensor,
    ) -> torch.Tensor:
        return self.lm_head(hidden_states)

    def load_model(
        self,
        path: str,
        *,
        use_tqdm: bool = False,
    ) -> None:
        all_shards = glob(os.path.join(path, "*.safetensors"))
        for file in (
            tqdm.tqdm(all_shards, desc="Loading model") if use_tqdm else all_shards
        ):
            with safe_open(file, "pt", "cpu") as f:
                for weight_name in f.keys():
                    weight_tensor = f.get_tensor(weight_name)
                    is_loaded = False

                    # Load packed modules
                    for k in self.packed_modules_mapping:
                        if k in weight_name:
                            v, shard_id = self.packed_modules_mapping[k]
                            param_name = weight_name.replace(k, v)
                            param = self.get_parameter(param_name)
                            weight_loader = getattr(param, "weight_loader")
                            weight_loader(param, weight_tensor, shard_id)
                            is_loaded = True
                            break

                    # Load other modules

                    if not is_loaded:
                        param = self.get_parameter(weight_name)
                        weight_loader = getattr(
                            param,
                            "weight_loader",
                            lambda p, loaded_weight: p.data.copy_(loaded_weight),
                        )
                        weight_loader(param, weight_tensor)
                        is_loaded = True

                    assert is_loaded, f"Weight {weight_name} not loaded"
