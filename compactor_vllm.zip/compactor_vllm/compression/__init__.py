from compactor_vllm.compression.common import (
    BaseCompressionMethod,
    CompressionMethod,
    NoCompression,
)
from compactor_vllm.compression.compactor import CompactorCompression
from compactor_vllm.compression.compression_params import BatchCompressionParams
from compactor_vllm.compression.snapkv import SnapKVCompression

COMPRESSION_REGISTRY: dict[CompressionMethod, type[BaseCompressionMethod]] = {
    CompressionMethod.COMPACTOR: CompactorCompression,
    CompressionMethod.SNAPKV: SnapKVCompression,
    CompressionMethod.NONE: NoCompression,
}

__all__ = ["CompressionMethod", "COMPRESSION_REGISTRY", "BatchCompressionParams"]
